//
//  Result.swift
//  FlickrSearchProject
//
//  Created by Aashna Narula on 22/03/19.
//  Copyright © 2019 Aashna Narula. All rights reserved.
//

import Foundation

enum Result<ResultType> {
    case results(ResultType)
    case error(Error)
}

