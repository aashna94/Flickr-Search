//
//  FlickrSearchResults.swift
//  FlickrSearchProject
//
//  Created by Aashna Narula on 22/03/19.
//  Copyright © 2019 Aashna Narula. All rights reserved.
//

import Foundation

struct FlickrSearchResults {
    let searchTerm : String
    let searchResults : [FlickrPhoto]
}
